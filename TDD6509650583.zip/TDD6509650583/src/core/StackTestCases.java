package core;

import junit.framework.TestCase;

public class StackTestCases extends TestCase {

	//TC1
	public void testCreateNewEmptyStack() {
		Stack s1 = new Stack();
		assertEquals(true,s1.isEmpty());
		
		//assertEquals(0,s1.getSize());
	}
	
	//TC2
	public void testPushElmToTop(){
		
		Stack s2 = new Stack();
		boolean isFullStack = s2.isFull();
		
		if(isFullStack == false) {
			s2.push(new Integer (1));
			int num = (Integer)s2.top();
			assertEquals(1,num);
		}
	
	}
	
	
}
