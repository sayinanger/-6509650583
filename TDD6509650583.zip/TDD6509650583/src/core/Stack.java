package core;

public class Stack implements IStack {
	
	private int max = 100;
	private Object[] array=new Object [max];
	int size = 0;

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return true;
	}

	
	public boolean isFull() {
		// TODO Auto-generated method stub
		return false;
	}

	public void push(Object elm) {
		// TODO Auto-generated method stub
		array[size] = elm;
		size++;
	}

	
	public Object top() {
		// TODO Auto-generated method stub
	   return array[size -1];
	}

	
	
}
